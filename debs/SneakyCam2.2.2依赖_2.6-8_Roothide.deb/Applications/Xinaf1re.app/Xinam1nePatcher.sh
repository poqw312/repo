#!/bin/bash

### v2.6-8

## This Patcher does any of the following automatically:

## Theme Converter (works on arm and arm64 debs)
## Xinam1ne Patcher (rootfull to rootless)
## Reverse Patcher (rootless to rootfull)

export TMPDIR=/var/mobile/Documents/.Xinaf1re

set -e

if ! type dpkg-deb >/dev/null 2>&1; then
    echo "Please install 'dpkg-deb'."
fi
if ! type file >/dev/null 2>&1; then
    echo "Please install 'file' from Bingner or Procursus."
fi
if ! type otool >/dev/null 2>&1 || ! type install_name_tool >/dev/null 2>&1; then
    echo "Please install 'odcctools'."
fi
if ! type plutil >/dev/null 2>&1; then
    echo "Please install 'plutil'."
fi
if ! type awk >/dev/null 2>&1; then
    echo "Please install 'gawk'."
fi
if ! type ldid >/dev/null 2>&1; then
    echo "Please install 'ldid'."
fi
if ! type dpkg-deb >/dev/null 2>&1 || ! type file >/dev/null 2>&1 || ! type otool >/dev/null 2>&1 || ! type otool >/dev/null 2>&1 || ! type plutil >/dev/null 2>&1 || ! type ldid >/dev/null 2>&1 || ! type awk >/dev/null 2>&1; then
    exit 1
fi

OLD="$(mktemp -qd)"
NEW="$(mktemp -qd)"
chmod 755 "$OLD"
chmod 755 "$NEW"

if [ ! -d "$OLD" ] || [ ! -d "$NEW" ]; then
    echo "Creating temporary directories failed."
    exit 1;
fi

### Script start
dpkg-deb -R "$1" "$OLD"
cp -a "$OLD"/DEBIAN "$NEW"

## Theme converter
if [ -d "$OLD/var/jb/Library/Themes" ] || [ -d "$OLD/Library/Themes" ]; then
if [ -d "$OLD/var/jb/Library/Themes" ]; then
    sed -i '/^Architecture: / s|iphoneos-arm64|iphoneos-arm|' "$NEW"/DEBIAN/control
    rm -rf "$OLD"/DEBIAN
    mv -f "$OLD"/var/jb/.* "$OLD"/var/jb/* "$NEW" >/dev/null 2>&1 || true
elif [ -d "$OLD/Library/Themes" ]; then
    sed -i '/^Architecture: / s|iphoneos-arm|iphoneos-arm64|' "$NEW"/DEBIAN/control
    rm -rf "$OLD"/DEBIAN
    mkdir -p "$NEW"/var/jb
    mv -f "$OLD"/.* "$OLD"/* "$NEW"/var/jb >/dev/null 2>&1 || true
fi
## Theme converter end

### Xinam1ne Patching Start
elif [ ! -d "$OLD/var/jb" ]; then
    ## Xinamine control file changes
    mkdir -p "$NEW"/var/jb
    sed 's|iphoneos-arm|iphoneos-arm64|' < "$OLD"/DEBIAN/control > "$NEW"/DEBIAN/control
    chmod -R 755 "$NEW"/DEBIAN >/dev/null 2>&1
    chmod 644 "$NEW"/DEBIAN/control >/dev/null 2>&1
    rm -rf "$OLD"/DEBIAN
    sed -i '/^Depends: / s|, xinaa15||' "$NEW"/DEBIAN/control
    sed -i '/^Depends: / s/$/, xyz.cypwn.xinam1ne/' "$NEW"/DEBIAN/control
#    sed -i '/^Version: / s/$/-xp/' "$NEW"/DEBIAN/control
    mv -f "$OLD"/.* "$OLD"/* "$NEW"/var/jb >/dev/null 2>&1 || true
    if [ -d "$NEW"/var/jb/var/mobile/Library/Designer ]; then
        mkdir -p "$NEW"/var/mobile/Library
        mv -f "$NEW"/var/jb/var/mobile/Library/Designer* "$NEW"/var/mobile/Library
        rm -rf "$NEW"/var/jb/var
    fi
    #remove xinam1ne dependency for simple debs
    if [ ! -d "$NEW"/var/jb/Library/PreferenceLoader ] && [ ! -d "$NEW"/var/jb/Library/Application\ Support ] && [ ! -d "$NEW"/var/jb/Library/PreferenceBundles ]; then
        sed -i 's|, xyz.cypwn.xinam1ne||g' "$NEW"/DEBIAN/control
    fi
    ## Xinam1ne Overall Patching Start
    find "$NEW" -type f | grep -viE '\.(jpg|jpeg|png|gif|mov|mp3|mp4|m4r|wav|otf|ttf)$' | while read -r file; do
        if file -ib "$file" | grep -q "x-mach-binary; charset=binary"; then
            INSTALL_NAME=$(otool -D "$file" | grep -v -e ":$" -e "^Archive :" | head -n1)
            install_name_tool -id @rpath/"$(basename "$INSTALL_NAME")" "$file" >/dev/null 2>&1
            DYLIBRPATH=$(otool -L "$file" | grep DynamicLibraries | cut -d' ' -f1 | tr -d "[:blank:]")
            if [ ! -z "$DYLIBRPATH" ]; then
                install_name_tool -add_rpath /var/jb/Library/MobileSubstrate/DynamicLibraries "$file" >/dev/null 2>&1
                install_name_tool -change "$DYLIBRPATH" @rpath/$(basename "$DYLIBRPATH") "$file" >/dev/null 2>&1
            fi
            # List of changes in the format "old_path:new_path"
            changes="/Library/Frameworks/CydiaSubstrate.framework/CydiaSubstrate:@rpath/libsubstrate.dylib
/Library/Frameworks/CepheiPrefs.framework/CepheiPrefs:@rpath/CepheiPrefs.framework/CepheiPrefs
/Library/Frameworks/Cephei.framework/Cephei:@rpath/Cephei.framework/Cephei
/Library/Frameworks/Alderis.framework/Alderis:@rpath/Alderis.framework/Alderis
/Library/Frameworks/AltList.framework/AltList:@rpath/AltList.framework/AltList
/Library/Frameworks/FLEXFramework.framework/FLEXFramework:@rpath/FLEXFramework.framework/FLEXFramework
/Library/Frameworks/Orion.framework/Orion:@rpath/Orion.framework/Orion
/Library/Frameworks/HyperixaKit.framework/HyperixaKit:@rpath/HyperixaKit.framework/HyperixaKit
/Library/Frameworks/libhdev.framework/libhdev:@rpath/libhdev.framework/libhdev
/usr/lib/libapplist.dylib:@rpath/libapplist.dylib
/usr/lib/libcolorpicker.dylib:@rpath/libcolorpicker.dylib
/usr/lib/libCSColorPicker.dylib:@rpath/libCSColorPicker.dylib
/usr/lib/libgcuniversal.dylib:@rpath/libgcuniversal.dylib
/usr/lib/librocketbootstrap.dylib:@rpath/librocketbootstrap.dylib
/usr/lib/libsparkcolourpicker.dylib:@rpath/libsparkcolourpicker.dylib
/usr/lib/libsparkapplist.dylib:@rpath/libsparkapplist.dylib"

            # Loop through each change and apply it
            IFS="
            "
            for change in $changes; do
                old_path=$(echo "$change" | cut -d: -f1)
                new_path=$(echo "$change" | cut -d: -f2)
                install_name_tool -change "$old_path" "$new_path" "$file" >/dev/null 2>&1
            done

            # Handle rpath modifications
            install_name_tool -delete_rpath "/Library/Frameworks" "$file" >/dev/null 2>&1 || true
            install_name_tool -delete_rpath "/usr/lib" "$file" >/dev/null 2>&1 || true
            install_name_tool -add_rpath "/var/jb/Library/Frameworks" "$file" >/dev/null 2>&1 || true
            install_name_tool -add_rpath "/var/jb/usr/lib" "$file" >/dev/null 2>&1 || true

            ### Xinam1ne Patch Binaries w/ exceptions and revert certain paths
            sed -i \
                    -e 's#\x00/Library#\x00/var/LIY#g' \
                    -e 's#\x00/bin/sh#\x00/var/sh#g' \
                    -e 's#\x00/usr/lib#\x00/var/lib#g' \
                    -e 's#\x00/usr/local#\x00/var/local#g' \
                    -e 's#\x00/usr/bin#\x00/var/bin#g' \
                    -e 's#\x00/private/var/mobile/Library/Preferences#\x00/private/var/jb/vmo/Library/Preferences#g' \
                    -e 's#\x00/var/mobile/Library/Preferences#\x00/var/jb/vmo/Library/Preferences#g' \
                    -e 's#\x00/var/mobile/Library/Application#\x00/var/jb/vmo/Library/Application#g' \
                    -e 's#\x00/Applications#\x00/var/jb/Xapps#g' \
                    -e 's#\x00/User/Library#\x00/var/jb/UsrLb#g' \
                    -e 's#\x00Library/MobileSub#\x00var/LIY/MobileSub#g' \
                    -e 's#\x00Library/dpkg#\x00var/lib/dpkg#g' \
                    -e 's#\x00Library/Sn#\x00var/LIY/Sn#g' \
                    -e 's#\x00Library/Th#\x00var/LIY/Th#g' \
                    -e 's#\x00Library/Application#\x00var/LIY/Application#g' \
                    -e 's#\x00Library/LaunchD#\x00var/LIY/LaunchD#g' \
                    -e 's#\x00Library/PreferenceB#\x00var/LIY/PreferenceB#g' \
                    -e 's#\x00Library/PreferenceL#\x00var/LIY/PreferenceL#g' \
                    -e 's#\x00Library/Frameworks#\x00var/LIY/Frameworks#g' \
                    -e 's#\x00bin/sh#\x00var/sh#g' \
                    -e 's#\x00usr/lib#\x00var/lib#g' \
                    -e 's#\x00usr/local#\x00var/local#g' \
                    -e 's#\x00usr/bin#\x00var/bin#g' \
                    -e 's#\x00private/var/mobile/Library/Preferences#\x00private/var/jb/vmo/Library/Preferences#g' \
                    -e 's#\x00var/mobile/Library/Preferences#\x00var/jb/vmo/Library/Preferences#g' \
                    -e 's#/var/mobile/Library/Preferences#/var/jb/vmo/Library/Preferences#g' \
                    -e 's#\x00var/mobile/Library/Application#\x00var/jb/vmo/Library/Application#g' \
                    -e 's#\x00Applications#\x00var/jb/Xapps#g' \
                    -e 's#\x00User/Library#\x00var/jb/UsrLb#g' \
                    -e 's#\x00Library/Act#\x00var/LIY/Act#g' \
                    -e 's#\x00Library/Flip#\x00var/LIY/Flip#g' \
                    -e 's#\x00Library/Switch#\x00var/LIY/Switch#g' \
                    -e 's#\x00Library/Hyp#\x00var/LIY/Hyp#g' \
                    -e 's#\x00Library/OH#\x00var/LIY/OH#g' \
                    -e 's#\x00Library/Emer#\x00var/LIY/Emer#g' \
                    -e 's#\x00Library/Har#\x00var/LIY/Har#g' \
                    -e 's#\x00Library/Spec#\x00var/LIY/Spec#g' \
                    -e 's#\x00Library/Cyl#\x00var/LIY/Cyl#g' \
                    -e 's#\x00Library/Jarv#\x00var/LIY/Jarv#g' \
                    -e 's#\x00Library/AhAh#\x00var/LIY/AhAh#g' \
                    -e 's#\x00Library/Tweak S#\x00var/LIY/Tweak S#g' \
                    -e 's#\x00/var/lib/libobjc.A.dylib#\x00/usr/lib/libobjc.A.dylib#g' \
                    -e 's#\x00/var/lib/libc++.1.dylib#\x00/usr/lib/libc++.1.dylib#g' \
                    -e 's#\x00/var/lib/libSystem.B.dylib#\x00/usr/lib/libSystem.B.dylib#g' \
                    -e 's#\x00/var/lib/libstdc++.6.dylib#\x00/usr/lib/libstdc++.6.dylib#g' \
                    -e 's#\x00/var/lib/libMobileGestalt.dylib#\x00/usr/lib/libMobileGestalt.dylib#g' \
                    -e 's#\x00/var/lib/system/#\x00/usr/lib/system/#g' \
                    -e 's#\x00/var/lib/dyld#\x00/usr/lib/dyld#g' \
                    -e 's#\x00/var/lib/swift#\x00/usr/lib/swift#g' \
                    -e 's#\x00/var/lib/libswift#\x00/usr/lib/libswift#g' \
                    -e 's#\x00/var/lib/libsql#\x00/usr/lib/libsql#g' \
                    -e 's#\x00/var/lib/libz#\x00/usr/lib/libz#g' \
            "$file"
            ldid -S "$file"
        ## Xinam1ne Patch .plist files
        elif basename "$file" | grep -q ".plist"; then
            plutil -convert xml1 "$file" >/dev/null 2>&1
            sed -i \
                    -e's#>/Applications/#>/var/jb/Applications/#g' \
                    -e 's#>/Library/i#>/var/LIY/i#g' \
                    -e 's#>/usr/share/#>/var/share/#g' \
                    -e 's#>/usr/bin/#>/var/bin/#g' \
                    -e 's#>/usr/lib/#>/var/lib/#g' \
                    -e 's#>/usr/sbin/#>/var/sbin/#g' \
                    -e 's#>/usr/libexec/#>/var/libexec/#g' \
                    -e 's#>/usr/local/#>/var/local/#g' \
                    -e 's#>/usr/#>/var/jb/usr/#g' \
                    -e 's#>/etc/#>/var/etc/#g' \
                    -e 's#>/bin/#>/var/bin/#g' \
                    -e 's#>/Library/#>/var/LIY/#g' \
                    -e 's#>/var/mobile/Library/Pref#>/var/jb/var/mobile/Library/Pref/#g' \
            "$file"
        fi
    done
    ## Patch /DEBIAN preinst, postinst, prerm, postrm
    find "$NEW"/DEBIAN -type f | while read -r file; do
        if basename "$file" | grep -vq "control" && file -ib "$file" | grep -vq "x-mach-binary; charset=binary"; then
            sed -i \
                    -e 's#\[:space:]##g' \
                    -e 's#\[]#\ #g' \
                    -e 's# /Applications/# /var/jb/Applications/#g' \
                    -e 's# /Library/i# /var/LIY/i#g' \
                    -e 's# /usr/share/# /var/share/#g' \
                    -e 's# /usr/bin/# /var/bin/#g' \
                    -e 's# /usr/lib/# /var/lib/#g' \
                    -e 's#/usr/sbin/#/var/sbin/#g' \
                    -e 's#/usr/libexec/#/var/libexec/#g' \
                    -e 's#/usr/local/#/var/local/#g' \
                    -e 's# /usr/# /var/jb/usr/#g' \
                    -e 's# /etc/# /var/etc/#g' \
                    -e 's# /bin/# /var/bin/#g' \
                    -e 's# /Library/# /var/LIY/#g' \
                    -e 's# "/Applications/# "/var/jb/Applications/#g' \
                    -e 's# "/Library/i# "/var/LIY/i#g' \
                    -e 's# "/usr/share/# "/var/share/#g' \
                    -e 's# "/usr/bin/# "/var/bin/#g' \
                    -e 's# "/usr/lib/# "/var/lib/#g' \
                    -e 's#"/usr/sbin/#"/var/sbin/#g' \
                    -e 's#"/usr/libexec/#"/var/libexec/#g' \
                    -e 's#"/usr/local/#"/var/local/#g' \
                    -e 's# "/usr/# "/var/jb/usr/#g' \
                    -e 's# "/etc/# "/var/etc/#g' \
                    -e 's# "/bin/# "/var/bin/#g' \
                    -e 's# "/Library/# "/var/LIY/#g' \
            "$file"
            ## shebang handler
            bangsh="#!/bin/sh"
            bangbash="#!/bin/bash"
            ## Check if the first line contains a shebang
            if [ "$(head -c 2 "$file")" = "#!" ]; then
                if [ "$(head -c 2 "$file")" = "/sh" ]; then
                    ## Replace sh shebang with new sh shebang
                    sed -i '1s|.*|'"$bangsh"'|' "$file"
                else
                    ## Replace existing shebang with new bash shebang
                    sed -i '1s|.*|'"$bangbash"'|' "$file"
                fi
            else
                ## Add new bash shebang as the first line
                sed -i '1s|^|'"$bangbash"'\n\n|' "$file"
            fi
            ## end shebang handler
        fi
    done
    ### Xinam1ne Patching End

### Rootless to Rootful Patching Start
elif [ -d "$OLD/var/jb" ]; then
    ## Rootless to Rootfull control file changes
#    sed -i '/^Package: / s/$/rootless/' "$OLD"/DEBIAN/control  ## adds "rootless" to end of Package line
#    sed -i '/^Name: / s/$/ (rootless)/' "$OLD"/DEBIAN/control ## adds " (rootless)" to end of Name line
    sed -i \
            -e '/^Package: / s|-rootless||' \
            -e '/^Package: / s|-Rootless||' \
            -e '/^Package: / s|rootless||' \
            -e '/^Package: / s|Rootless||' \
            -e '/^Name: / s| (rootless)||' \
            -e '/^Name: / s| (Rootless)||' \
            -e '/^Depends: / s|, xyz.cypwn.xinam1ne||' \
            -e '/^Depends: / s|firmware (>=15|firmware (>=14|' \
            -e '/^Depends: / s|firmware (>= 15|firmware (>= 14|' \
    "$OLD"/DEBIAN/control
    sed '/^Architecture: / s|iphoneos-arm64|iphoneos-arm|' < "$OLD"/DEBIAN/control > "$NEW"/DEBIAN/control
#    sed 's|iphoneos-arm64|iphoneos-arm|' < "$OLD"/DEBIAN/control > "$NEW"/DEBIAN/control
    rm -rf "$OLD"/DEBIAN
    mv -f "$OLD"/.* "$OLD"/* "$NEW" >/dev/null 2>&1 || true
    ## Rootless to Rootfull Overall Patching Start
    find "$NEW" -type f | grep -viE '\.(jpg|jpeg|png|gif|mov|mp3|mp4|m4r|wav|otf|ttf)$' | while read -r file; do
        if file -ib "$file" | grep -q "x-mach-binary; charset=binary"; then
#            echo "$file"
            INSTALL_NAME=$(otool -D "$file" | grep -v -e ":$" -e "^Archive :" | head -n1)
            otool -L "$file" | tail -n +2 | grep -e /System | grep /Library/'[^/]'\*.dylib | cut -d' ' -f1 | tr -d "[:blank:]" > "$OLD"/._lib_cache
            if [ -n "$INSTALL_NAME" ]; then
                install_name_tool -id @rpath/"$(basename "$INSTALL_NAME")" "$file" >/dev/null 2>&1
            fi
            if otool -L "$file" | grep -q CydiaSubstrate; then
                install_name_tool -change @rpath/CydiaSubstrate.framework/CydiaSubstrate @rpath/libsubstrate.dylib "$file" >/dev/null 2>&1
            fi
            if [ -f "$OLD"/._lib_cache ]; then
                cat "$OLD"/._lib_cache | while read line; do
                install_name_tool -change "$line" @rpath/"$(basename "$line")" "$file" >/dev/null 2>&1
                done
            fi
            install_name_tool -delete_rpath "/var/jb/Library/Frameworks" "$file" >/dev/null 2>&1 || true
            install_name_tool -delete_rpath "/var/jb/usr/lib" "$file" >/dev/null 2>&1 || true
            install_name_tool -add_rpath "/Library/Frameworks" "$file" >/dev/null 2>&1 || true
            install_name_tool -add_rpath "/usr/lib" "$file" >/dev/null 2>&1 || true
            ### Rootless to Rootfull Patch Binaries
            sed -i \
                    -e 's#\x00/var/jb/Library/MobileSubstrate#\x00/Library/MobileSubstrate///////#g' \
                    -e 's#\x00/var/jb/Library/PreferenceBundles#\x00/Library/PreferenceBundles///////#g' \
                    -e 's#\x00/var/jb/Library/PreferenceLoader#\x00/Library/PreferenceLoader///////#g' \
                    -e 's#\x00/var/jb/var/mobile/Library/Preferences#\x00/var/mobile/Library/Preferences///////#g' \
                    -e 's#\x00/var/jb/Library/Application Support#\x00/Library/Application Support///////#g' \
                    -e 's#\x00/var/jb/Applications#\x00/Applications///////#g' \
                    -e 's#\x00/var/jb\x00#\x00///////\x00#g' \
                    -e 's#\x00/var/jb/usr/bin#\x00/usr/bin///////#g' \
                    -e 's#\x00/var/jb/usr/lib/#\x00/usr/lib////////#g' \
                    -e 's#\x00/var/jb/usr/sbin#\x00/usr/sbin///////#g' \
                    -e 's#\x00/var/jb/sbin#\x00/usr/sbin///#g' \
                    -e 's#\x00/var/jb/usr/local/bin#\x00/usr/local/bin///////#g' \
                    -e 's#\x00/var/jb/usr/libexec#\x00/usr/libexec///////#g' \
                    -e 's#\x00/var/jb/usr/local#\x00/usr/local/////////#g' \
                    -e 's#\x00/var/jb/User/Library/Preferences#\x00/var/mobile/Library/Preferences/#g' \
                    -e 's#/var/jb/vmo/Library/Preferences#/var/mobile/Library/Preferences#g' \
                    -e 's#\x00/var/jb#\x00///////#g' \
                    -e 's#\x00/var/LIY#\x00/Library#g' \
                    -e 's#\x00var/LIY#\x00Library#g' \
                    -e 's#var/LIY#Library#g' \
                    -e 's#var/bin#usr/bin#g' \
            "$file"
            ldid -S "$file"
        ## Rootless to Rootfull Patch .plist files
        elif basename "$file" | grep -q ".plist"; then
            plutil -convert xml1 "$file" >/dev/null 2>&1
            sed -i \
                    -e 's#>/var/jb/Applications/#>/Applications/#g' \
                    -e 's#>/var/jb/Library/i#>/Library/i#g' \
                    -e 's#>/var/jb/usr/share/#>/usr/share/#g' \
                    -e 's#>/var/jb/usr/bin/#>/usr/bin/#g' \
                    -e 's#>/var/jb/usr/lib/#>/usr/lib/#g' \
                    -e 's#>/var/jb/usr/sbin/#>/usr/sbin/#g' \
                    -e 's#>/var/jb/usr/libexec/#>/usr/libexec/#g' \
                    -e 's#>/var/jb/usr/local/#>/usr/local/#g' \
                    -e 's#>/var/jb/usr/#>/usr/#g' \
                    -e 's#>/var/jb/etc/#>/etc/#g' \
                    -e 's#>/var/jb/bin/#>/bin/#g' \
                    -e 's#>/var/jb/Library/#>/Library/#g' \
                    -e 's#>/var/jb/var/mobile/Library/Pref#>/var/mobile/Library/Pref/#g' \
                    -e 's#>/var/jb/#>/#g' \
                    -e 's#>/var/LIY/#>/Library/#g' \
                    -e 's#>/var/share/#>/usr/share/#g' \
                    -e 's#>/var/sbin/#>/usr/sbin/#g' \
                    -e 's#>/var/libexec/#>/usr/libexec/#g' \
                    -e 's#>/var/local/#>/usr/local/#g' \
                    -e 's#>/var/etc/#>/etc/#g' \
                    -e 's#>/var/jb/vmo/Library/Pref#>/var/mobile/Library/Pref/#g' \
            "$file"
        fi
    done
    mkdir -p "$NEW"/temp
    mv -f "$NEW"/var/jb/.* "$NEW"/var/jb/* "$NEW"/temp >/dev/null 2>&1 || true
    rm -rf "$NEW"/var/jb
    if [ -d "$NEW"/temp/var/jb/usr/lib/TweakInject ]; then
        mkdir -p "$NEW"/temp/var/jb/Library/MobileSubstrate
        mv "$NEW"/temp/var/jb/usr/lib/TweakInject "$NEW"/temp/var/jb/Library/MobileSubstrate/DynamicLibraries
        rm -rf "$NEW"/temp/var/jb/usr/lib/TweakInject
    fi
    if [ -d "$NEW"/temp/var/jb/usr/lib ]; then
        [ "$(ls -A "$NEW"/temp/var/jb/usr/lib)" ] && : || rm -rf "$NEW"/temp/var/jb/usr/lib
    fi
    if [ -d "$NEW"/temp/var/jb/usr ]; then
        [ "$(ls -A "$NEW"/temp/var/jb/usr)" ] && : || rm -rf "$NEW"/temp/var/jb/usr
    fi
    mv -f "$NEW"/temp/var/jb/.* "$NEW"/temp/var/jb/* "$NEW" >/dev/null 2>&1 || true
    rm -rf "$NEW"/temp/var/jb
    [ -d "$NEW"/var ] && [ "$(ls -A "$NEW"/var)" ] && : || rm -rf "$NEW"/var
    mv -f "$NEW"/temp/.* "$NEW"/temp/* "$NEW" >/dev/null 2>&1 || true
    rm -rf "$NEW"/temp
    ## Rootless to Rootfull Patch /DEBIAN preinst, postinst, prerm, postrm
    find "$NEW"/DEBIAN -type f | while read -r file; do
        if basename "$file" | grep -vq "control" && file -ib "$file" | grep -vq "x-mach-binary; charset=binary"; then
            sed -i \
                    -e 's#/var/jb##g' \
                    -e 's#\[:space:]##g' \
                    -e 's#\[]#\ #g' \
                    -e 's# /var/jb/Applications/# /Applications/#g' \
                    -e 's# /var/LIY/i# /Library/i#g' \
                    -e 's# /var/share/# /usr/share/#g' \
                    -e 's# /var/bin/# /usr/bin/#g' \
                    -e 's# /var/lib/# /usr/lib/#g' \
                    -e 's#/var/sbin/#/usr/sbin/#g' \
                    -e 's#/var/libexec/#/usr/libexec/#g' \
                    -e 's#/var/local/#/usr/local/#g' \
                    -e 's# /var/jb/usr/# /usr/#g' \
                    -e 's# /var/etc/# /etc/#g' \
                    -e 's# /var/bin/# /bin/#g' \
                    -e 's# /var/LIY/# /Library/#g' \
                    -e 's# "/var/jb/Applications/# "/Applications/#g' \
                    -e 's# "/var/LIY/i# "/Library/i#g' \
                    -e 's# "/usr/share/# "/var/share/#g' \
                    -e 's# "/var/bin/# "/usr/bin/#g' \
                    -e 's# "/var/lib/# "/usr/lib/#g' \
                    -e 's#"/var/sbin/#"/usr/sbin/#g' \
                    -e 's#"/var/libexec/#"/usr/libexec/#g' \
                    -e 's#"/var/local/#"/usr/local/#g' \
                    -e 's# "/var/jb/usr/# "/usr/#g' \
                    -e 's# "/var/etc/# "/etc/#g' \
                    -e 's# "/var/bin/# "/bin/#g' \
                    -e 's# "/var/LIY/# "/Library/#g' \
            "$file"
            ## shebang handler
            bangsh="#!/bin/sh"
            bangbash="#!/bin/bash"
            ## Check if the first line contains a shebang
            if [ "$(head -c 2 "$file")" = "#!" ]; then
                if [ "$(head -c 2 "$file")" = "/sh" ]; then
                    ## Replace sh shebang with new sh shebang
                    sed -i '1s|.*|'"$bangsh"'|' "$file"
                else
                    ## Replace existing shebang with new bash shebang
                    sed -i '1s|.*|'"$bangbash"'|' "$file"
                fi
            else
                ## Add new bash shebang as the first line
                sed -i '1s|^|'"$bangbash"'\n\n|' "$file"
            fi
            ## end shebang handler
        fi
    done
    ### Rootless to Rootful Patching End
fi
### Script end
/var/jb/usr/local/bin/Xinam1ne 2> /dev/null

##Redeb
dpkg-deb -b "$NEW" "/var/mobile/Documents/.Xinaf1re"/"$(grep Package: "$NEW"/DEBIAN/control | cut -f2 -d ' ')"_"$(grep Version: "$NEW"/DEBIAN/control | cut -f2 -d ' ')"_"$(grep Architecture: "$NEW"/DEBIAN/control | cut -f2 -d ' ')".deb >/dev/null 2>&1
chown 501:501 "/var/mobile/Documents/.Xinaf1re"/"$(grep Package: "$NEW"/DEBIAN/control | cut -f2 -d ' ')"_"$(grep Version: "$NEW"/DEBIAN/control | cut -f2 -d ' ')"_"$(grep Architecture: "$NEW"/DEBIAN/control | cut -f2 -d ' ')".deb >/dev/null 2>&1

## Cleaning up
rm -rf "$OLD" "$NEW"
